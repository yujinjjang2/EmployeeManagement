package edu.kh.emp.run;

import edu.kh.emp.view.EmployeeView;

public class EmployeeRun {
	
	public static void main(String[] args) {
		
	
		EmployeeView ev = new EmployeeView();
		
		ev.displayMenu();
		
	}

}
